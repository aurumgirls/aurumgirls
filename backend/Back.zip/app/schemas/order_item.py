from pydantic import BaseModel, ConfigDict, Field


class OrderItemBase(BaseModel):
    product_id: str
    quantity: int = Field(gt=0)


class OrderItemCreate(OrderItemBase):
    pass


class OrderItemOut(OrderItemBase):
    id: str
    order_id: str
    price: float

    model_config = ConfigDict(from_attributes=True)