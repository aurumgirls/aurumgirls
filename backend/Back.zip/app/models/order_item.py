import uuid
from sqlalchemy import Column, String, Integer, Float, ForeignKey
from app.database import Base


class OrderItem(Base):
    __tablename__ = "order_items"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    order_id = Column(String, ForeignKey("order"), nullable=False)
    product_id = Column(String, ForeignKey("product.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)