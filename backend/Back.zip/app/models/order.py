import uuid
from sqlalchemy import Column, String, Float, Datetime
from sqlalchemy.sql import func

from app.database import Base

class Order(Base):
    __tablename__ = "orders"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    total = Column(Float, nullable=False)
    status = Column(String, nullable=False, default="pending")
    created_at = Column(Datetime(timezone=True), server_default=func.now())